from django.apps import AppConfig


class PosAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pos_admin'
